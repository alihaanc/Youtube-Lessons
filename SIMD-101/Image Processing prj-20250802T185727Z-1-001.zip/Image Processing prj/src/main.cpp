#include <opencv2/opencv.hpp>
#include <immintrin.h> // AVX intrinsics için gerekli
#include <iostream>
#include <format>
#include <string_view>
#include <vector>
#include <chrono>
#include "Alignass.hpp"
#include <memory>

#if defined(__AVX__)
#define AVX_ENABLE 1
#else
#define AVX_ENABLE 0
#endif

static_assert(AVX_ENABLE == 1);
constexpr  std::string resim ="aslan.bmp";


/// @brief CPP 20 standardıyla gelen format library ile kullnılan print fonksiyonu
/// @param str_fmt
/// @param ...args
constexpr void print(const std::string_view str_fmt, auto &&...args)
{
    fputs(std::vformat(str_fmt, std::make_format_args(args...)).c_str(),
          stdout);
}
/// @brief Bu fonksiyon normal bir şekilde grileştirme yapar
/// @param src kaynak veri
/// @param dest sonucun tutulacağı veri
/// @param width  Kaynağın enlem olarak pixel adeti
/// @param height  Kaynağın boylam olarak pixel adeti
/// @param times Performans ölçümü için gerekli döngü sayısı
void convertToGrayscale(const unsigned char *src, unsigned char *dest, int width, int height, size_t times)
{
    int numPixels = width * height;
    for (size_t i = 0; i < times; ++i)
    {
        for (int i = 0; i < numPixels; ++i)
        {
            int r = src[i * 3 + 0];
            int g = src[i * 3 + 1];
            int b = src[i * 3 + 2];
            unsigned char gray = static_cast<unsigned char>((r + g + b) / 3);
            dest[i] = gray;
        }
    }
}
/// @brief AVX ve AVX2 kullanarak  yapılan Grileştirme işlemi
/// @param image  Kaynak görüntü
/// @param width  Kaynağın enlem olarak pixel adeti
/// @param height Kaynağın boylam olarak pixel adeti
/// @param times  Performans ölçümü için gerekli döngü sayısı
void convertToGrayscaleAVX_struct(std::vector<unsigned char> &image, int width, int height, size_t times)
{
    int numPixels = width * height;

    // Orijinal resmi kaydet
    std::vector<unsigned char> originalImage = image;

    Buffer_i rgb0, r, g, b, grayInt;
    Buffer_ft rFloat, gFloat, bFloat, gray;
    __m256i mask = _mm256_set1_epi32(0x000000FF);
    /*0x000000FF maskesi, 32-bit'lik her bir bileşenin 
    sadece en düşük 8 bitini (bir renk bileşenini) izole etmek için kullanılır.*/

    // Ağırlık katsayıları
    __m256 rWeight = _mm256_set1_ps(0.2989f);
    __m256 gWeight = _mm256_set1_ps(0.5870f);
    __m256 bWeight = _mm256_set1_ps(0.1140f);

    size_t blockSize = 32; // 32-byte blok boyutu
    size_t numBlocks = (numPixels * 3) / blockSize; // Tam bloklar
    size_t remainingPixels = (numPixels * 3) % blockSize; // Kalan elemanlar

    for (size_t t = 0; t < times; ++t)
    {
        image = originalImage; 

        for (size_t i = 0; i < numBlocks; ++i)
        {
            size_t offset = i * 32;

            if (offset + 32 <= image.size()) // Sınır kontrolü
            {
                rgb0.m256i_buffer = _mm256_loadu_si256(reinterpret_cast<const __m256i *>(&image[offset]));

                r.m256i_buffer = _mm256_and_si256(rgb0.m256i_buffer, mask); // Kırmızı 0-8bit
                g.m256i_buffer = _mm256_and_si256(_mm256_srli_epi32(rgb0.m256i_buffer, 8), mask); // Yeşil 8-16 bit
                b.m256i_buffer = _mm256_and_si256(_mm256_srli_epi32(rgb0.m256i_buffer, 16), mask); // Mavi 16-24 bit
                /*  32-bit'lik her bir bileşeni sağa kaydırır. 
                yeşil ve mavi bileşenler elde edilir.*/

                rFloat.m256_buffer = _mm256_cvtepi32_ps(r.m256i_buffer);
                gFloat.m256_buffer = _mm256_cvtepi32_ps(g.m256i_buffer);
                bFloat.m256_buffer = _mm256_cvtepi32_ps(b.m256i_buffer);

             
                rFloat.m256_buffer = _mm256_mul_ps(rFloat.m256_buffer, rWeight);
                gFloat.m256_buffer = _mm256_mul_ps(gFloat.m256_buffer, gWeight);
                bFloat.m256_buffer = _mm256_mul_ps(bFloat.m256_buffer, bWeight);

                gray.m256_buffer = _mm256_add_ps(rFloat.m256_buffer, _mm256_add_ps(gFloat.m256_buffer, bFloat.m256_buffer));

              
                grayInt.m256i_buffer = _mm256_cvtps_epi32(gray.m256_buffer); //32-bit
                grayInt.m256i_buffer = _mm256_packus_epi32(grayInt.m256i_buffer, grayInt.m256i_buffer); // AVX2 //16-bit
                /*_mm256_packus_epi32: 32-bit tamsayıları 16-bit'e indirger ve saturate (taşma durumunda sınırlandırma) işlemi yapar. 
                Bu, elde edilen 32-bit'lik gri tonlama değerlerini 8-bit(RGB den her biri 8 bittir) formatına dönüştürmek için kullanilir.*/

                // Gri tonlama sonuçlarını görüntüye kaydet
                _mm256_storeu_si256(reinterpret_cast<__m256i *>(&image[offset]), grayInt.m256i_buffer);
            }
        }

          if (remainingPixels > 0)
        {
            size_t startIdx = numBlocks * blockSize;
            unsigned char* remainingData = image.data() + startIdx;//0-255
            /*Toplam veri boyutu: 1000 * 3 = 3000 bayt
            Tam blok sayısı: 3000 / 32 = 93 blok
            Kalan bayt: 3000 % 32 = 12 bayt*/

            // Kalan pikseller
            for (size_t i = 0; i < remainingPixels; i += 3)
            {
                float r = remainingData[i] * 0.2989f;
                float g = remainingData[i + 1] * 0.5870f;
                float b = remainingData[i + 2] * 0.1140f;
                unsigned char gray = static_cast<unsigned char>(r + g + b);
                remainingData[i] = gray;
                remainingData[i + 1] = gray;
                remainingData[i + 2] = gray;
            }
        }
    }
}

/// @brief AVX ve Opencv ilk ayarlamalar
/// @param times  Performans ölçümü için gerekli döngü sayısı
/// @return anlık hatadan kaçmak için kullanılmayan veri döner
int AVX_grayScaleInit_and_Process(int times)
{

    cv::Mat colorImage = cv::imread(resim);

    if (colorImage.empty())
    {
        std::cerr << "Resim yüklenemedi!" << std::endl;
        return -1;
    }

    int width = colorImage.cols;
    int height = colorImage.rows;
    std::vector<unsigned char> imageData(colorImage.data, colorImage.data + colorImage.total() * colorImage.elemSize());

    // Gri tonlama işlemini AVX ile yap
    convertToGrayscaleAVX_struct(imageData, width, height, times);

    cv::Mat processedImage(height, width, CV_8UC3, imageData.data());
    cv::imwrite("output_avx.bmp", processedImage);

    cv::namedWindow("Color Image", cv::WINDOW_NORMAL);
    cv::resizeWindow("Color Image", 64, 48);

    cv::namedWindow("processedImage", cv::WINDOW_NORMAL);
    cv::resizeWindow("processedImage", 64, 48);

    return 0;
}

/// @brief Standart Opencv grileştirme işlemi
/// @param times Performans ölçümü için gerekli döngü sayısı
/// @return anlık hatadan kaçmak için kullanılmayan veri döner
int OPENCV_grayScaleInit_and_Process(size_t times)
{
    for (size_t j = 0; j < times; ++j)
    {

        cv::Mat colorImage = cv::imread(resim);

        // Görüntünün başarıyla yüklendiğini kontrol et
        if (colorImage.empty())
        {
            std::cerr << "Resim yüklenemedi!" << std::endl;
            return -1;
        }
         cv::Mat grayImage;

        cv::cvtColor(colorImage, grayImage, cv::COLOR_BGR2GRAY);

        
        cv::imwrite("output_gray.bmp", grayImage);

        cv::namedWindow("Color Image", cv::WINDOW_NORMAL);
        cv::resizeWindow("Color Image", 64, 48);

        cv::namedWindow("Gray Image", cv::WINDOW_NORMAL);
        cv::resizeWindow("Gray Image", 64, 48);
    }
    return 0;
}
/// @brief Bu fonksiyon Normal bir Grileştirme metodudur ve verilerin ortalaması şeklinde hesaplar
/// @param times Performans ölçümü için gerekli döngü sayısı
/// @return anlık hatadan kaçmak için kullanılmayan veri döner
int normalGrayScale(size_t times)
{
    cv::Mat colorImage = cv::imread(resim);

    if (colorImage.empty())
    {
        std::cerr << "Resim yüklenemedi!" << std::endl;
        return -1;
    }

    int width = colorImage.cols;
    int height = colorImage.rows;

 
   std::vector<unsigned char> imageData(colorImage.data, colorImage.data + colorImage.total() * colorImage.elemSize());

  
   std::vector<unsigned char> grayImage(width * height);

    
    convertToGrayscale(imageData.data(), grayImage.data(), width, height, times);

    cv::Mat grayImageMat(height, width, CV_8UC1, grayImage.data());

    cv::imwrite("output_grayscale.bmp", grayImageMat);

    cv::namedWindow("Color Image", cv::WINDOW_NORMAL);
    cv::resizeWindow("Color Image", 64, 48);

    cv::namedWindow("Gray Image", cv::WINDOW_NORMAL);
    cv::resizeWindow("Gray Image", 64, 48);

    return 0;
}

using seconds = std::chrono::duration<double>;
using miliseconds = std::chrono::duration<double, std::milli>;
using microseconds = std::chrono::duration<double, std::micro>;
using take_current_time = std::chrono::high_resolution_clock;

int main()
{
    size_t times = 100;
    auto start = take_current_time::now();
    normalGrayScale(times);
    auto end = take_current_time::now();
    seconds duration_opencv = (end - start);
    print("\nDuration opencv Image processing: {} s\n*******************************\n", duration_opencv.count());

#if AVX_ENABLE

    start = take_current_time::now();
    AVX_grayScaleInit_and_Process(times);
    end = take_current_time::now();
    seconds duration_AVX = (end - start);
    print("Duration AVX Image processing: {} s\n\n", duration_AVX.count());

#else
    print("AVX not ENABLED.\n");
#endif

    return 0;
}
