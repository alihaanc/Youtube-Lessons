#include "Alignass.hpp"

 /// @brief float tip tanımlaması için  bufferı sıfırlayıcı yöntem
void Buffer_ft::zero(){

    m256_buffer = _mm256_setzero_ps();

}

/// @brief float tip tanımlaması için yapıcı elaman
Buffer_ft::Buffer_ft(){

    zero();
}

 /// @brief int tip tanımlaması için  bufferı sıfırlayıcı yöntem
 void Buffer_i::zero(){

 m256i_buffer = _mm256_setzero_si256();

 }


 /// @brief int tip tanımlaması için yapıcı elaman
 Buffer_i::Buffer_i(){

    zero();
 }
