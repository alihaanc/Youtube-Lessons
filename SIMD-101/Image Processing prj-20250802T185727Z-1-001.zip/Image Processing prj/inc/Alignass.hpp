#ifndef ALIGANS_HPP
#define ALIGANS_HPP

#include <immintrin.h>
#include<iostream>
#include <memory>

constexpr auto AVX_FLOAT_COUNT = 8u; //her seferinde 8 tane float islemi icin
constexpr auto AVX_INT_COUNT = 8u; // her seferinde 8 tane int işlemi için

/// @brief float tipinde hizalı buffer tip tanımlaması
struct alignas(AVX_FLOAT_COUNT * alignof(float)) Buffer_ft {

	union {

		float arr_f[8];
		__m256 m256_buffer;

	};

	Buffer_ft();
	void zero();

};

/// @brief int tipinde hizalı buffer tip tanımlaması
struct alignas(AVX_INT_COUNT * alignof(int)) Buffer_i {

    union {
        int arr_i[8];       
        __m256i m256i_buffer; 
    };

  
    Buffer_i();

    
    void zero();
};


struct alignas(AVX_FLOAT_COUNT * alignof(float)) avx_alignment_t {};
static_assert(sizeof(avx_alignment_t) == AVX_FLOAT_COUNT * sizeof(float));


static_assert(sizeof(Buffer_ft) == AVX_FLOAT_COUNT * sizeof(float));
static_assert(sizeof(Buffer_i) == AVX_INT_COUNT * sizeof(int));


#endif